using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Piece : MonoBehaviour
{
    float lastFall = 0;
    public bool current = false;

    void Start()
    {
        lastFall = 0;
        if (!IsValidBoard())
		{
            Debug.Log("GAME OVER");
        }
    }

    void Update()
    {
        // Move Left
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            transform.position += new Vector3(-1, 0, 0);
            if (!IsValidBoard())
                transform.position += new Vector3(1, 0, 0);
        }
        else if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            transform.position += new Vector3(1, 0, 0);

            if (!IsValidBoard())
                transform.position += new Vector3(-1, 0, 0);
                    
        }
        else if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            transform.Rotate(0, 0, -90);

            if (!IsValidBoard())
                transform.Rotate(0, 0, 90);
        }
        else if (Input.GetKeyDown(KeyCode.DownArrow) ||
                    Time.time - lastFall >= 1)
        {
            transform.position += new Vector3(0, -1, 0);

            if (!IsValidBoard())
            {
                transform.position += new Vector3(0, 1, 0);
                EnableBlocksFromPiece();
                Hide();
                Board.DeleteFullRows();

                FindObjectOfType<Spawner>().SpawnNext();
            }

            lastFall = Time.time;
        }
    }

    void Hide() {
        transform.position = new Vector3(-10, -10, 0);
    }

    void EnableBlocksFromPiece()
    {
        foreach (Transform child in transform)
        {
            Vector2 v = Board.RoundVector2(child.position);
            Board.grid[(int)v.x, (int)v.y].SetActive(true);
        }
    }

    bool IsValidBoard()
    {
        foreach (Transform child in transform)
        {
            Vector2 v = Board.RoundVector2(child.position);
			if (!Board.InsideBorder(v) || Board.grid[(int)v.x, (int)v.y].activeSelf == true)
                return false;
        }
        return true;
    }



}
