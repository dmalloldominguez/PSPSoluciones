using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject cell;
    public GameObject[] pieces;
    private GameObject[] piecesPool;
    private Piece currentPiece;

    void Start()
    {
        piecesPool = new GameObject[pieces.Length];
        for (int i = 0; i < pieces.Length; i++){
            piecesPool[i] = Instantiate(pieces[i], transform.position + new Vector3(-10, -10, 0), Quaternion.identity);
            piecesPool[i].SetActive(false);
        }
        Board.PopulateGrid(cell);

        SpawnNext();   
    }

    void Update()
    {
    }

    public void SpawnNext()
    {
        if (currentPiece!=null) currentPiece.gameObject.SetActive(false);
        int i = Random.Range(0, pieces.Length);
		currentPiece = piecesPool[i].GetComponent<Piece>();
        piecesPool[i].transform.position = transform.position;
        piecesPool[i].SetActive(true);
    }
}
