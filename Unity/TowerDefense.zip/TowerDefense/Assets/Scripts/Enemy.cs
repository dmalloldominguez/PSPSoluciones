using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Enemy : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        GameObject castle = GameObject.Find("Egg");
        if (castle)
            GetComponent<NavMeshAgent>().destination = castle.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        if (gameObject.GetComponentInChildren<HealthBar>().current() <= 0) {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter(Collider co)
    {
        // If castle then deal Damage
        if (co.name == "Egg")
        {
            co.GetComponentInChildren<HealthBar>().decrease();
            Destroy(gameObject);
        }
    }
}
