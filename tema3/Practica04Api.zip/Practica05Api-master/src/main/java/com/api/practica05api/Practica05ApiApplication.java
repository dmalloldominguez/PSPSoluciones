package com.api.practica05api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practica05ApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(Practica05ApiApplication.class, args);
    }

}
